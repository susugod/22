$(function(){
	checkSelected();
	//统计方法选择时调用checkSelected方法
	$('#tj').on('change',function(){
		checkSelected();
	})
	//根据统计方法改变已选择样本的内容
	function checkSelected(){
		var oSelected=$('#tj').val();
		// console.log(oSelected);  	
		switch (oSelected) {
			//描述统计
			case '1': 	
				$('.show01').show();
				$('.show02,.show03').hide();
				break;
			//两样本均值差异比较	
			case '2': 	
				$('.show02').show();
				$('.show01,.show03').hide();
				break;
			//方差分析	
			case '3': 
				$('.show03').show();
				$('.show01,.show02').hide();
				break;
		}		
	}
	// 添加样本	 	
	$('#add-sample').on('click',function(){
		var num03=$('.sample-group').size();
		var newSample='<div class="sample-group"><h5><input id="sample0'+num03+1+'" type="checkbox"> <label for="sample0'+num03+1+'">样本'+(num03+1)+'</label></h5></div>'
		$('.sample-groups').append(newSample);
		num03++;
	})
	//单选radio取消选择
	$(document).on('click','.sample-groups:radio',function () {
		var r = $(this).attr("name");
		$(":radio[name=" + r + "]:not(:checked)").attr("tag", 0);
		if ($(this).attr("tag") == 1) {
			$(this).attr("checked", false);
			$(this).attr("tag", 0);
		}
		else {
			$(this).attr("tag",1);
		}
	});
	// 统计分析的删除样本
	$('#remove-sample').on('click',function(){
		var num=$('.sample-group').size();
		// console.log(num);
		childrenNum=$('.sample-group').children('h5').size(),
		oSelectRadio=$(".sample-groups input:radio:checked"),
		oSelectcheck=$(".sample-groups input:checkbox:checked");
		if(oSelectRadio.size() < 1 && oSelectcheck.size() < 1){
			alert('请选择要删除的对象');
			return;
		}
		if((childrenNum=3||$('.sample-group .radiobox').size()>0)&&((num-2)>oSelectcheck.size())){
			if(oSelectRadio){
				$(oSelectRadio).parents('.radiobox').remove();
			} 
			if(oSelectcheck){
				$(oSelectcheck).parent().parent().remove();
			}
		}else{
			alert('抱歉，删除后样本组数量大于等于3')
		}
	});
	// 综合报告的删除样本
	$('#deleate-sample').on('click',function(){
		// 样本数
		var num=$('.sample-group').size();
		// console.log(num);
		// h5数量
		h5s=$('.sample-group').children('h5').size(),
		// 子项
		radios=$(".sample-groups input:radio:checked"),
		// 方框选择
		checks=$(".sample-groups input:checkbox:checked");
		// 判断选择框数量
		if(radios.size() < 1 && checks.size() < 1){
			alert('请选择要删除的对象');
			return;
		}
		if((h5s=1||$('.sample-group .radiobox').size()>1)&&(num>checks.size())){
			if(radios){
				$(radios).parents('.radiobox').remove();
			} 
			if(checks){
				$(checks).parents('.sample-group').remove();
			}
		}else{
			alert('抱歉，删除后样本组数量大于等于1');

		}
	})
})